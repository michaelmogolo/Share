<?php
session_start();
require_once 'App/Autoloader.class.php';
Autoloader::register();
$modules = scandir('module/');
if(isset($_GET['module']) && !empty($_GET['module']) && in_array($_GET['module'],$modules))
{
    $module = $_GET['module'];
    $pages = scandir('module/'.$module.'/pages/');
    $page = (isset($_GET['p']) && !empty($_GET['p']) && in_array($_GET['p'].'.php',$pages))?$pages=$_GET['p']:'home';

}
elseif(!isset($_GET['module']) && empty($_GET['module']))
{
    $module = 'default';
    $pages = scandir('module/'.$module.'/pages/');
    $page = (isset($_GET['p']) && !empty($_GET['p']) && in_array($_GET['p'].'.php',$pages))?$pages=$_GET['p']:'home';

}
else
{
    $module = 'default';
    $page = 'home';
}
$content = ob_get_clean();
require_once 'module/'.$module.'/template.php';
