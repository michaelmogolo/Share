/* JS Document */
// by Michael Geek
/******************************

[Table of Contents]
1.the of hide and show article of article
2.the function triggleClick to genere a Event Click
3.the function for choice the picture and to show them in the Screen




******************************/

$(document).ready(function()
{
	$('.w-imgLastDesc').hover(function(){
		$(this).css("cursor","pointer");
		$(this).css("display","block");
		$(this).addClass("padd");
		
		  
	  },
	  function(){
		$(this).removeClass("padd");
	  });
	  
});
function triggleClick(){

	document.getElementById('imgp').click();
}
function Dimg(e){
	if(e.files[0]){
		var reader = new FileReader();

		reader.onload = function(e){
			document.getElementById('profileD').setAttribute('src', e.target.result);

		}
		reader.readAsDataURL(e.files[0]);
	}
}
var modal = document.getElementById("wModal");
var btn = document.getElementById("wUpp");
var span = document.getElementsByClassName("w-close")[0];
btn.onclick = function() {
  modal.style.display = "block";
}
span.onclick = function() {
  modal.style.display = "none";
}
window.onclick = function() {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
var modalAdd = document.getElementById("wadd");
var btnAdd = document.getElementById("WApp");
btnAdd.onclick = function(){
	modalAdd.style.display ="block";
}
var  span2 = document.getElementsByClassName('wClose')[0];
span2.onclick= function(){
	modalAdd.style.display ="none";
}
window.onclick = function(event) {
	if (event.target == modalAdd) {
	  modalAdd.style.display = "none";
	}
  }
  var modalDel= document.getElementById("wdel");
var btnDel = document.getElementById("wdel");
btnDel.onclick = function(){
	modalAdd.style.display ="block";
}
var  span3 = document.getElementsByClassName('Wclose')[0];
span3.onclick= function(){
	modalAdd.style.display ="none";
}
window.onclick = function(event) {
	if (event.target == modalDel) {
	  modalDel.style.display = "none";
	}
  }


//bar


