<?php

/**
 * by Michael Geek
 */

class Article extends Table{
    public function All(){
        return self::query('SELECT*FROM `humanitarian`');
    }
    public static function getArticle($id){
        return self::query('SELECT * FROM `humanitarian` WHERE `id` =?',[$id]);
    }
    public static function add_article($fields){
        $attributes = [];
        foreach($fields as $att=> $key){
            $attributes[]= $key;
        }
        self::query('INSERT INTO`humanitarian`(`Name`,`Description`,`Picture`) VALUES(?,?,?)',$attributes,true);
    }
    public static function update($fields)
    {
       $attributes = [];
       foreach($fields as $att => $key)
       {
          $attributes[] = $key;
       }

     self::query('UPDATE `humanitarian` SET `Name`= ?, `Description`= ?, `Picture`= ? WHERE`id`=?', $attributes, true);
    }
    public static  function  delete($id){
        return self::query("DELETE FROM `humanitarian` WHERE `id`=$id");
    }
    public static function search($content){
        return self::query("SELECT*FROM `humanitarian` WHERE `Name` LIKE '%$content%' 
        OR `Description` LIKE '%$content%'");
    }
}