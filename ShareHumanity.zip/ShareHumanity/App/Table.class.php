<?php
/**
 * by Michael Geek
 */
class Table{
    public static function query($statement,$attribut=null,$one = false){
        if($attribut){
            return App::getDb()->prepare($statement,$attribut,get_called_class(),$one);
        }
        else{
            return App::getDb()->query($statement,get_called_class(),$one);
        }
    }
}