<?php
require_once '../../app/Autoloader.class.php';
Autoloader::register();
$json = array('error' => false);

if (isset($_REQUEST['action'])) {

    $actions = scandir('action/');
    if(in_array($_REQUEST['action'].'.php', $actions)){

        require 'action/'.$_REQUEST['action'].'.php';

    }
}

echo json_encode($json);