<?php
session_start();

$mode_edition= 0;
if(isset($_GET) && !empty($_GET))
{
    $getId = $_GET['id'];
    Article::delete($getId);
    header("Location:../../?p=home");
    
}
    
else{
    echo "gggg";
}
