<?php
Article::search($_POST['search']);
header('location:../../?p=search&q='. urlencode($_POST['search'])); 
