<?php
session_start();
if(isset($_POST) && !empty($_POST)){
    $nom = htmlspecialchars($_POST['Name']);
    $Description = htmlspecialchars($_POST['Description']);
    $img =$_FILES['profilimage'];
    $datas = array($nom,$Description,$img['name']);
    if(!empty($nom) && !empty($Description) && !empty($img['name'])){
        if(isset($img)&& !empty($img['name'])){
        $link = '../../Public/img/'.$img['name'];
            $tail = 2097152;
            $extension_Valide = array('jpg','jpeg','png','gif');
            if($img['size'] <= $tail)
            {
                
                $extension_Upload = strtolower(substr(strrchr($img['name'],'.'),1));
                if(in_array($extension_Upload,$extension_Valide)){
                    move_uploaded_file($img['tmp_name'],$link);
                    Article::add_article($datas);
                   header('Location:../../index.php?p=home');
                   echo"ok";
                }
                else{
                    echo "non non";
                }

            }
        }
    }
}
else{
    echo"mal";
}
// if(isset($_POST) && !empty($_POST))
// {
//     $nom = htmlspecialchars($_POST['Name']);
//     $Description = htmlspecialchars($_POST['Description']);
//     $img =htmlspecialchars($_POST['img']);
//     $datas = array($nom,$Description,$img);
//     if(!empty($nom) && !empty($Description) && !empty($img))
//     {
//         Utility::sendPhoto($img,'public/img/');
//         // Article::addArticle($datas);
        
//         $succeed= "Your register is succeed";
        
//     }
//     else
//     {
//         header('location:../../index.php?p=register&error=please complete your formular!');
//     }

// }