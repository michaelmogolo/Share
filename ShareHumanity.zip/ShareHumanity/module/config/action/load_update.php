<?php
session_start();

$mode_edition= 0;
if(isset($_POST) && !empty($_POST))
{
    if(isset($_POST['modifier']))
    {
        
        $titre = htmlspecialchars($_POST['Nom']);
        $contenu = htmlspecialchars($_POST['Description']);
        $img = $_FILES['profilimage'];
        $getId = htmlspecialchars($_GET['id']);
        $datas = array($titre,$contenu,$img,$getId);
        if( isset($img) && !empty($img['name']))
        {
            $link = '../../Public/img/'.$img['name'];
                $tail = 2097152;
                $extension_Valide = array('jpg','jpeg','png','gif');
                if($img['size'] <= $tail)
                {
                    
                    $extension_Upload = strtolower(substr(strrchr($img['name'],'.'),1));
                    if(in_array($extension_Upload,$extension_Valide)){
                        move_uploaded_file($img['tmp_name'],$link);
                        Article::update($datas);
                        header('Location:../../?p=home');
                    
                    }
                    else{
                        echo "non non";
                    }

                }
        }
    }
            
            
    else{
        echo "ca marche pas frere";
    }
}
else{
    echo "gggg";
}
