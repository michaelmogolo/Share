<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="keywords" content="">
    <meta name="robots" content="all, index, follow">
    <meta name="author" content="">
    
    <meta property="og:site_name" content="">
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
        
    <meta property="og:image:type" content="image/jpg">
    <meta property="og:image:width" content="640">
    <meta property="og:image:height" content="410">
    <link rel="stylesheet" type="text/css" href="public/style/css/main.css">
    <link rel="stylesheet" type="text/css" href="public/style/css/bootstrap.css">
    <link rel="stylesheet" href="public/style/css/WithColor.css">
    <link rel="stylesheet" type="text/css" href="public/style/css/css/font-awesome.css">
    <!-- Setting for all version of I-E -->

      <!-- Just for debugging purposes. Don't actually copy this line! -->
      <!--[if lt IE 9]><script src="../../docs-assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

      <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
      <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
      <![endif]-->
      <title>Share Humanity</title>
</head>
<body>
<div class="w-bar-header ">
        <h4>Sharer Humanity</h4>
    </div>
    <div class="<?= ($page !== 'home') ? 'container' : '' ?>" >
        
        <?php require_once 'module/'.$module.'/pages/'.$page.'.php'; ?>
        
    </div>
</body>
<script src="public/style/js/jquery.js"></script>
    <script src="public/style/js/bootstrap.min.js"></script>
    <script src="public/style/js/main.js"></script> 
</body>
</html>