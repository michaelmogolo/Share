<div class="container">
                <h4><b><a href="../index.html" class="w-cl-black ">My Dashboard</a> / <a href="./post.html" class="w-cl-black">Post</a>/ <a href="./poster.html" class="w-cl-black">Poster</a></b></h4><br>
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <div class="w-img-view ">
                            <h6 class="text-center" id="putP"><b>put your image here <i class="fa fa-arrow-down" aria-hidden="true"></i></b></h6>
                            <img src="../img/icons8_Add_File_2.svg" alt="" onclick="triggleClick()" id="profileD">
                            <input type="file" name="" id="imgp" onchange="Dimg(this)" style="display: none;">
                        </div>
                    </div>
                    <div class="col-12 col-lg-6">
                        <div class="w-form">
                            <div class="form-group">

                              <label for="">Title</label>
                              <input type="text" name="" id="" class="form-control" placeholder="Title" aria-describedby="helpId">
                            </div>
                            <div class="form-group">
                              <label for="">Description</label>
                              <textarea name="" id="" cols="50" rows="10" class="form-control" placeholder="Saisir votre text..."></textarea>
                            </div>
                            <div class="form-group">
                                <button class="w-btn w-bord-blueSky w-bord-rd"><a href="view.html" class="w-cl-white"> Ajouter <i class="fa fa-plus" aria-hidden="true"></i></a></button>
                                <button class="w-btn w-bord-red w-bord-rd"><a href="view.html" class="w-cl-white"> Supprimer <i class="fa fa-close" aria-hidden="true"></i></a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>