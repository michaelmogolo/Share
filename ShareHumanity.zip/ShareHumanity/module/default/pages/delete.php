<?php $article= Article::getArticle($_GET['id']);?>
<br><br><br>
<div class="row">
    <?php foreach($article as $post){?>
        <form action="module/config/index.php?p=action&action=_delete&id=<?=$post->id;?>" method="POST"  enctype="multipart/form-data">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <img src="public/img/<?=$post->Picture;?>" alt="" onclick="triggleClick()" id="profileD" class="w-circle-img">
                    <input type="file" name="profilimage" id="imgp" onchange="Dimg(this)" style="display: none;">
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <h4><?=$post->Name;?></h4>
                    </div>
                    <div class="form-group">
                    <label for="">Description</label>
                    <p><?=$post->Description;?></p>
                    </div>
                    <a href=""class="w-btn w-bord-blueSky w-cl-white"><input type="submit" style="border:none;" class="w-bord-blueSky" value="Confirmer" name="supprimer"> <i class="fa fa-pencil" aria-hidden="true"></i></a>
                    <a href="?p=home"><input type="submit" class="w-btn w-bord-red" value="Annuler"> <i class="fa fa-close" aria-hidden="true"></i></a>
                            
                </div>
            </div>
        </form>
        
   <?php }?>
</div>