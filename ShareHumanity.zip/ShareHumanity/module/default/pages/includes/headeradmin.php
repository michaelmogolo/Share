<div class="container">
    <div class="row">
        <div class=" col-12 col-lg-12">
            <div class="w-d-grid-5">
                <div>
                    <form class="form-inline " method="POST" action="module/config/index.php?p=action&action=search_article">
                        <input class="form-control mr-sm-1 "id="sr" type="search" placeholder="Search" aria-label="Search" name="search">
                        <button class="w-btn w-bord-blueSky w-bord-rd m-1"><i class="fa fa-search"></i> Recherche</button> 
                    </form>
                </div>
                <div>
                    <button class=" w-btn w-bord-blueSky w-bord-rd" id="wUpp">Add <i class="fa fa-plus" aria-hidden="true"></i></button> 
                </div>
            </div>
        </div>
    </div>

    
    <div class="w-modal" id="wModal">
        <div class="w-modal-content">
            <span class="w-close"><i class="fa fa-close"></i></span>
            <div class="container">
                <h3 class="text-center">Add a Article</h3><br>
                <div class="row">
                    <div class="col-12 col-lg-12">
                       <form action="module/config/index.php?p=action&action=_register" method="POST" class="form-group" enctype="multipart/form-data">
                            <div class="w-d-grid">
                                <div class="">
                                    <img src="public/img/sv2.svg" alt="" onclick="triggleClick()" id="profileD" class="w-circle-img">
                                    <input type="file" name="profilimage" id="imgp" onchange="Dimg(this)" style="display: none;">
                                </div>
                            <div>
                                <div class="form-group">
                                    <label for="Nom">Name :</label>
                                    <input type="text" class="form-control col-lg-12" name="Name">
                                </div>
                                <div class="form-group">
                                    <label for="">Description</label>
                                    <textarea name="Description" placeholder="..." id="" cols="50" rows="10" class="form-control"></textarea>
                                </div>
                                <a href="#"class="w-btn w-bord-blueSky w-cl-white"><input type="submit" style="border:none;" class="w-bord-blueSky" value="Confirmer"> <i class="fa fa-pencil" aria-hidden="true"></i></a>
                                <a href="#"><input type="submit" class="w-btn w-bord-red" value="Annuler"> <i class="fa fa-close" aria-hidden="true"></i></a>
                            </div>
                       </div>
                       </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="w-modal-add" id="wadd">
        <div class="w-modal-content">
            <span class="wClose"><i class="fa fa-close"></i></span>
            <div class="container">
            <div class="container">
                <h3 class="text-center">Add a Article</h3><br>
                <div class="row">
                    <div class="col-12 col-lg-12">
                       <form action="Config/config/index.php?p=action&action=_register" method="POST" class="form-group" enctype="multipart/form-data">
                            <div class="w-d-grid">
                                <div class="">
                                    <img src="public/img/sv2.svg" alt="" onclick="triggleClick()" id="profileD" class="w-circle-img">
                                    <input type="file" name="profilimage" id="imgp" onchange="Dimg(this)" style="display: none;">
                                </div>
                            <div>
                                <div class="form-group">
                                    <label for="Nom">Name :</label>
                                    <input type="text" class="form-control col-lg-12" name="Name">
                                </div>
                                <div class="form-group">
                                    <label for="">Description</label>
                                    <textarea name="Description" placeholder="..." id="" cols="50" rows="10" class="form-control"></textarea>
                                </div>
                                <a href="#"class="w-btn w-bord-blueSky w-cl-white"><input type="submit" style="border:none;" class="w-bord-blueSky" value="Confirmer"> <i class="fa fa-pencil" aria-hidden="true"></i></a>
                                <a href="#"><input type="submit" class="w-btn w-bord-red" value="Annuler"> <i class="fa fa-close" aria-hidden="true"></i></a>
                            </div>
                       </div>
                       </form>
                    </div>
                </div>
            </div>
              
            </div>
        </div>
    </div>
</div>