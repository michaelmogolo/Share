<?php $article= Article::getArticle($_GET['id']);?>
<br><br><br>
<div class="row">
    <?php foreach($article as $post){?>
        <form action="module/config/index.php?p=action&action=load_update&id=<?=$post->id;?>" method="POST"  enctype="multipart/form-data">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <img src="public/img/<?=$post->Picture;?>" alt="" onclick="triggleClick()" id="profileD" class="w-circle-img">
                    <input type="file" name="profilimage" id="imgp" onchange="Dimg(this)" style="display: none;">
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                    <label for="">Name :</label>
                    <input type="text" name="Nom" id="" class="form-control" placeholder="<?=$post->Name;?>" aria-describedby="helpId">
                    </div>
                    <div class="form-group">
                    <label for="">Description</label>
                    <textarea name="Description" placeholder="" id="" cols="50" rows="10" class="form-control"><?=$post->Description;?></textarea>
                    </div>
                    <a href="#"class="w-btn w-bord-blueSky w-cl-white"><input type="submit" style="border:none;" class="w-bord-blueSky" value="Confirmer" name="modifier"> <i class="fa fa-pencil" aria-hidden="true"></i></a>
                    <a href="#"><input type="submit" class="w-btn w-bord-red" value="Annuler"> <i class="fa fa-close" aria-hidden="true"></i></a>
                            
                </div>
            </div>
        </form>
        
   <?php }?>
</div>