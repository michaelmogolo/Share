<div class="content-all">
    
    <br>
    <div class="container">
        <div class="row">
            <div class="profil">
                
            </div>
            <div class="col-12 col-lg-12 mt-5">
            <?php include("includes/headeradmin.php")?>
                <br>
                <div class="row">
                    <?php 
                    $art = new Article();
                    foreach($art->All() as $post){;?>
                    <div class="col-12 col-lg-4">
                        <div class="card text-left">
                          <div class="card-img-top w-img-back" style="background-image: url('public/img/<?=$post->Picture;?>');">
                            <a href="?p=delete&id=<?=$post->id;?>" id=""><button type="submit" class="w-plus w-bord-red"><i class="fa fa-trash"></i></button></a>
                            <a href=?p=single&id=<?= $post->id;?>"><button type="submit" class="w-plus w-bord-blueSky"><i class="fa fa-pencil"></i></button></a>
                        </div>
                          <div class="card-body">
                            <h4 class="card-title "><?=$post->Name;?></h4>
                            <p class="card-text"><?=$post->Description;?></p>
                          </div>
                        </div>
                    </div>
                    <?php }?>
                </div>
            </div>
        </div>
    </div>
</div>